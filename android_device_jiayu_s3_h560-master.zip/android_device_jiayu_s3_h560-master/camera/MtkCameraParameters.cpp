/*
**
** Copyright 2008, The Android Open Source Project
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/

#define LOG_TAG "MTKCameraParams"
#include <utils/Log.h>

#include <string.h>
#include <stdlib.h>
#include "MtkCameraParameters.h"

namespace android {


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//  App Mode.
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
const char MtkCameraParameters::PROPERTY_KEY_CLIENT_APPMODE[]   = "client.appmode";
//
const char MtkCameraParameters::APP_MODE_NAME_DEFAULT[]         = "Default";
const char MtkCameraParameters::APP_MODE_NAME_MTK_ENG[]         = "MtkEng";
const char MtkCameraParameters::APP_MODE_NAME_MTK_ATV[]         = "MtkAtv";
const char MtkCameraParameters::APP_MODE_NAME_MTK_S3D[]         = "MtkS3d";
const char MtkCameraParameters::APP_MODE_NAME_MTK_VT[]          = "MtkVt";
const char MtkCameraParameters::APP_MODE_NAME_MTK_PHOTO[]       = "MtkPhoto";
const char MtkCameraParameters::APP_MODE_NAME_MTK_VIDEO[]       = "MtkVideo";
const char MtkCameraParameters::APP_MODE_NAME_MTK_ZSD[]         = "MtkZsd";

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//  Scene Mode
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
const char MtkCameraParameters::SCENE_MODE_NORMAL[] = "normal";

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//  Face Beauty
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
const char MtkCameraParameters::KEY_FB_SMOOTH_LEVEL[]       = "fb-smooth-level";
const char MtkCameraParameters::KEY_FB_SMOOTH_LEVEL_MIN[]   = "fb-smooth-level-min";
const char MtkCameraParameters::KEY_FB_SMOOTH_LEVEL_MAX[]   = "fb-smooth-level-max";
//
const char MtkCameraParameters::KEY_FB_SKIN_COLOR[]         = "fb-skin-color";
const char MtkCameraParameters::KEY_FB_SKIN_COLOR_MIN[]     = "fb-skin-color-min";
const char MtkCameraParameters::KEY_FB_SKIN_COLOR_MAX[]     = "fb-skin-color-max";
//
const char MtkCameraParameters::KEY_FB_SHARP[]              = "fb-sharp";
const char MtkCameraParameters::KEY_FB_SHARP_MIN[]          = "fb-sharp-min";
const char MtkCameraParameters::KEY_FB_SHARP_MAX[]          = "fb-sharp-max";
//
const char MtkCameraParameters::KEY_FB_ENLARGE_EYE[]        = "fb-enlarge-eye";
const char MtkCameraParameters::KEY_FB_ENLARGE_EYE_MIN[]    = "fb-enlarge-eye-min";
const char MtkCameraParameters::KEY_FB_ENLARGE_EYE_MAX[]    = "fb-enlarge-eye-max";
//
const char MtkCameraParameters::KEY_FB_SLIM_FACE[]          = "fb-slim-face";
const char MtkCameraParameters::KEY_FB_SLIM_FACE_MIN[]      = "fb-slim-face-min";
const char MtkCameraParameters::KEY_FB_SLIM_FACE_MAX[]      = "fb-slim-face-max";
//
const char MtkCameraParameters::KEY_FB_EXTREME_BEAUTY[]     = "fb-extreme-beauty";
//
const char MtkCameraParameters::KEY_FACE_BEAUTY[]           = "face-beauty";


//
const char MtkCameraParameters::KEY_EXPOSURE[] = "exposure";
const char MtkCameraParameters::KEY_EXPOSURE_METER[] = "exposure-meter";
const char MtkCameraParameters::KEY_ISO_SPEED[] = "iso-speed";
const char MtkCameraParameters::KEY_AE_MODE[] = "ae-mode";
const char MtkCameraParameters::KEY_FOCUS_METER[] = "focus-meter";
const char MtkCameraParameters::KEY_EDGE[] = "edge";
const char MtkCameraParameters::KEY_HUE[] = "hue";
const char MtkCameraParameters::KEY_SATURATION[] = "saturation";
const char MtkCameraParameters::KEY_BRIGHTNESS[] = "brightness";
const char MtkCameraParameters::KEY_CONTRAST[] = "contrast";
const char MtkCameraParameters::KEY_AF_LAMP_MODE [] = "aflamp-mode";
const char MtkCameraParameters::KEY_STEREO_3D_PREVIEW_SIZE[] = "stereo3d-preview-size";
const char MtkCameraParameters::KEY_STEREO_3D_PICTURE_SIZE[] = "stereo3d-picture-size";
const char MtkCameraParameters::KEY_STEREO_3D_TYPE [] = "stereo3d-type";
const char MtkCameraParameters::KEY_STEREO_3D_MODE [] = "stereo3d-mode";
const char MtkCameraParameters::KEY_STEREO_3D_IMAGE_FORMAT [] = "stereo3d-image-format";

// ZSD
const char MtkCameraParameters::KEY_ZSD_MODE[] = "zsd-mode"; 
const char MtkCameraParameters::KEY_SUPPORTED_ZSD_MODE[] = "zsd-supported";
//
const char MtkCameraParameters::KEY_FPS_MODE[] = "fps-mode";
//
const char MtkCameraParameters::KEY_FOCUS_DRAW[] = "af-draw";
//
const char MtkCameraParameters::KEY_CAPTURE_MODE[] = "cap-mode";
const char MtkCameraParameters::KEY_SUPPORTED_CAPTURE_MODES[] = "cap-mode-values";
const char MtkCameraParameters::KEY_CAPTURE_PATH[] = "capfname";
const char MtkCameraParameters::KEY_BURST_SHOT_NUM[] = "burst-num";
//
const char MtkCameraParameters::KEY_MATV_PREVIEW_DELAY[] = "tv-delay";
const char MtkCameraParameters::KEY_PANORAMA_IDX[] = "pano-idx";
const char MtkCameraParameters::KEY_PANORAMA_DIR[] = "pano-dir";

// Values for KEY_EXPOSURE
const char MtkCameraParameters::EXPOSURE_METER_SPOT[] = "spot";
const char MtkCameraParameters::EXPOSURE_METER_CENTER[] = "center";
const char MtkCameraParameters::EXPOSURE_METER_AVERAGE[] = "average";

// Valeus for KEY_ISO_SPEED
const char MtkCameraParameters::ISO_SPEED_AUTO[] = "auto";
const char MtkCameraParameters::ISO_SPEED_100[] = "100";
const char MtkCameraParameters::ISO_SPEED_200[] = "200";
const char MtkCameraParameters::ISO_SPEED_400[] = "400";
const char MtkCameraParameters::ISO_SPEED_800[] = "800";
const char MtkCameraParameters::ISO_SPEED_1600[] = "1600";

// Values for KEY_AE_MODE = "ae-mode"

// Values for KEY_FOCUS_METER
const char MtkCameraParameters::FOCUS_METER_SPOT[] = "spot";
const char MtkCameraParameters::FOCUS_METER_MULTI[] = "multi";

// AWB2PASS
const char MtkCameraParameters::KEY_AWB2PASS[] = "awb-2pass"; 


//
//  Camera Mode
const char MtkCameraParameters::KEY_CAMERA_MODE[] = "mtk-cam-mode";
// Values for KEY_CAMERA_MODE
const int MtkCameraParameters::CAMERA_MODE_NORMAL  = 0;
const int MtkCameraParameters::CAMERA_MODE_MTK_PRV = 1;
const int MtkCameraParameters::CAMERA_MODE_MTK_VDO = 2;
const int MtkCameraParameters::CAMERA_MODE_MTK_VT  = 3;

// Values for KEY_FPS_MODE
const int MtkCameraParameters::FPS_MODE_NORMAL = 0;
const int MtkCameraParameters::FPS_MODE_FIX = 1;

// Values for raw save mode

// Values for KEY_FOCUS_DRAW

// Values for capture mode
const char MtkCameraParameters::CAPTURE_MODE_PANORAMA_SHOT[] = "panoramashot";
const char MtkCameraParameters::CAPTURE_MODE_BURST_SHOT[] = "burstshot";
const char MtkCameraParameters::CAPTURE_MODE_NORMAL[] = "normal";
const char MtkCameraParameters::CAPTURE_MODE_BEST_SHOT[] = "bestshot";
const char MtkCameraParameters::CAPTURE_MODE_EV_BRACKET_SHOT[] = "evbracketshot";
const char MtkCameraParameters::CAPTURE_MODE_SMILE_SHOT[] = "smileshot";
const char MtkCameraParameters::CAPTURE_MODE_MAV_SHOT[] = "mav"; 
const char MtkCameraParameters::CAPTURE_MODE_AUTO_PANORAMA_SHOT[] = "autorama"; 
const char MtkCameraParameters::CAPTURE_MODE_MOTION_TRACK_SHOT[] = "motiontrack"; 
const char MtkCameraParameters::CAPTURE_MODE_HDR_SHOT[] = "hdr"; 
const char MtkCameraParameters::CAPTURE_MODE_ASD_SHOT[] = "asd"; 
const char MtkCameraParameters::CAPTURE_MODE_ZSD_SHOT[] = "zsd";
const char MtkCameraParameters::CAPTURE_MODE_PANO_3D[] = "pano_3d"; 
const char MtkCameraParameters::CAPTURE_MODE_SINGLE_3D[] = "single_3d"; 
const char MtkCameraParameters::CAPTURE_MODE_FACE_BEAUTY[] = "face_beauty"; 
const char MtkCameraParameters::CAPTURE_MODE_CONTINUOUS_SHOT[] = "continuousshot";
const char MtkCameraParameters::CAPTURE_MODE_MULTI_MOTION[] = "multi_motion";
const char MtkCameraParameters::CAPTURE_MODE_GESTURE_SHOT[] = "gestureshot";

// Values for panorama direction settings
const char MtkCameraParameters::PANORAMA_DIR_RIGHT[] = "right";
const char MtkCameraParameters::PANORAMA_DIR_LEFT[] = "left";
const char MtkCameraParameters::PANORAMA_DIR_TOP[] = "top";
const char MtkCameraParameters::PANORAMA_DIR_DOWN[] = "down";

//
const int MtkCameraParameters::ENABLE = 1;
const int MtkCameraParameters::DISABLE = 0;

// Values for KEY_EDGE, KEY_HUE, KEY_SATURATION, KEY_BRIGHTNESS, KEY_CONTRAST
const char MtkCameraParameters::HIGH[] = "high";
const char MtkCameraParameters::MIDDLE[] = "middle";
const char MtkCameraParameters::LOW[] = "low";

// Preview Internal Format.
const char MtkCameraParameters::KEY_PREVIEW_INT_FORMAT[] = "prv-int-fmt";

// Pixel color formats for KEY_PREVIEW_FORMAT, KEY_PICTURE_FORMAT,
// and KEY_VIDEO_FRAME_FORMAT
const char MtkCameraParameters::PIXEL_FORMAT_YUV420I[] = "yuv420i-yyuvyy-3plane";
const char MtkCameraParameters::PIXEL_FORMAT_YV12_GPU[] = "yv12-gpu";
const char MtkCameraParameters::PIXEL_FORMAT_YUV422I_UYVY[] = "yuv422i-uyvy";
const char MtkCameraParameters::PIXEL_FORMAT_YUV422I_VYUY[] = "yuv422i-vyuy";
const char MtkCameraParameters::PIXEL_FORMAT_YUV422I_YVYU[] = "yuv422i-yvyu";

const char MtkCameraParameters::PIXEL_FORMAT_BAYER8[] = "bayer8"; 
const char MtkCameraParameters::PIXEL_FORMAT_BAYER10[] = "bayer10";  

const char MtkCameraParameters::KEY_BRIGHTNESS_VALUE[] = "brightness_value";

// ISP Operation mode for meta mode use 
const char MtkCameraParameters::KEY_ISP_MODE[] = "isp-mode"; 
// AF 
const char MtkCameraParameters::KEY_AF_X[] = "af-x"; 
const char MtkCameraParameters::KEY_AF_Y[] = "af-y"; 
// Effect 
const char MtkCameraParameters::EFFECT_SEPIA_BLUE[] = "sepiablue";
const char MtkCameraParameters::EFFECT_SEPIA_GREEN[] = "sepiagreen";

//
//  on/off => FIXME: should be replaced with TRUE[]
const char MtkCameraParameters::ON[] = "on";
const char MtkCameraParameters::OFF[] = "off";
// 
const char MtkCameraParameters::WHITE_BALANCE_TUNGSTEN[] = "tungsten";
//
const char MtkCameraParameters::ISO_SPEED_ENG[] = "iso-speed-eng";
const char MtkCameraParameters::KEY_RAW_SAVE_MODE[] = "rawsave-mode";
const char MtkCameraParameters::KEY_RAW_PATH[] = "rawfname";

const char MtkCameraParameters::KEY_FAST_CONTINUOUS_SHOT[] = "fast-continuous-shot";

const char MtkCameraParameters::KEY_CSHOT_INDICATOR[] = "cshot-indicator";

// AF EM MODE
const char MtkCameraParameters::KEY_FOCUS_ENG_MODE[]		= "afeng-mode";
const char MtkCameraParameters::KEY_FOCUS_ENG_STEP[] 		= "afeng-pos";
const char MtkCameraParameters::KEY_FOCUS_ENG_MAX_STEP[] 	= "afeng-max-focus-step";
const char MtkCameraParameters::KEY_FOCUS_ENG_MIN_STEP[] 	= "afeng-min-focus-step";
const char MtkCameraParameters::KEY_FOCUS_ENG_BEST_STEP[]   = "afeng-best-focus-step";
const char MtkCameraParameters::KEY_RAW_DUMP_FLAG[]         = "afeng_raw_dump_flag";
const char MtkCameraParameters::KEY_PREVIEW_DUMP_RESOLUTION[] = "preview-dump-resolution";
// Values for KEY_PREVIEW_DUMP_RESOLUTION
const int MtkCameraParameters::PREVIEW_DUMP_RESOLUTION_NORMAL  = 0;
const int MtkCameraParameters::PREVIEW_DUMP_RESOLUTION_CROP  = 1;
//
const char MtkCameraParameters::KEY_MAX_NUM_DETECTED_OBJECT[] = "max-num-ot";
//
const char MtkCameraParameters::KEY_VIDEO_HDR[] = "video-hdr"; 

// KEY for [Engineer Mode] Add new camera paramters for new requirements
const char MtkCameraParameters::KEY_ENG_AE_ENABLE[] = "eng-ae-enable";
const char MtkCameraParameters::KEY_ENG_PREVIEW_SHUTTER_SPEED[] = "eng-preview-shutter-speed";
const char MtkCameraParameters::KEY_ENG_PREVIEW_SENSOR_GAIN[] = "eng-preview-sensor-gain";
const char MtkCameraParameters::KEY_ENG_PREVIEW_ISP_GAIN[] = "eng-preview-isp-gain";
const char MtkCameraParameters::KEY_ENG_PREVIEW_AE_INDEX[] = "eng-preview-ae-index";
const char MtkCameraParameters::KEY_ENG_CAPTURE_SENSOR_GAIN[] = "eng-capture-sensor-gain";
const char MtkCameraParameters::KEY_ENG_CAPTURE_ISP_GAIN[] = "eng-capture-isp-gain";
const char MtkCameraParameters::KEY_ENG_CAPTURE_SHUTTER_SPEED[] = "eng-capture-shutter-speed";
const char MtkCameraParameters::KEY_ENG_CAPTURE_ISO[] = "eng-capture-iso";
const char MtkCameraParameters::KEY_ENG_FLASH_DUTY_VALUE[] = "eng-flash-duty-value";
const char MtkCameraParameters::KEY_ENG_FLASH_DUTY_MIN[] = "eng-flash-duty-min";
const char MtkCameraParameters::KEY_ENG_FLASH_DUTY_MAX[] = "eng-flash-duty-max";
const char MtkCameraParameters::KEY_ENG_ZSD_ENABLE[] = "eng-zsd-enable";
const char MtkCameraParameters::KEY_SENSOR_TYPE[] = "sensor-type";
const char MtkCameraParameters::KEY_ENG_PREVIEW_FPS[] = "eng-preview-fps";
const char MtkCameraParameters::KEY_ENG_MSG[] = "eng-msg";
const int  MtkCameraParameters::KEY_ENG_FLASH_DUTY_DEFAULT_VALUE = -1;
const int  MtkCameraParameters::KEY_ENG_FLASH_STEP_DEFAULT_VALUE = -1;
const char MtkCameraParameters::KEY_ENG_FLASH_STEP_MIN[] = "eng-flash-step-min";
const char MtkCameraParameters::KEY_ENG_FLASH_STEP_MAX[] = "eng-flash-step-max";
const char MtkCameraParameters::KEY_ENG_FOCUS_FULLSCAN_FRAME_INTERVAL[] = "eng-focus-fullscan-frame-interval";
const char MtkCameraParameters::KEY_ENG_FOCUS_FULLSCAN_FRAME_INTERVAL_MAX[] = "eng-focus-fullscan-frame-interval-max";
const char MtkCameraParameters::KEY_ENG_FOCUS_FULLSCAN_FRAME_INTERVAL_MIN[] = "eng-focus-fullscan-frame-interval-min";
const int  MtkCameraParameters::KEY_ENG_FOCUS_FULLSCAN_FRAME_INTERVAL_MAX_DEFAULT = 65535;
const int  MtkCameraParameters::KEY_ENG_FOCUS_FULLSCAN_FRAME_INTERVAL_MIN_DEFAULT = 0;
const char MtkCameraParameters::KEY_ENG_PREVIEW_FRAME_INTERVAL_IN_US[] = "eng-preview-frame-interval-in-us";
const char MtkCameraParameters::KEY_ENG_PARAMETER1[] = "key-eng-parameter1";
const char MtkCameraParameters::KEY_ENG_PARAMETER2[] = "key-eng-parameter2";
const char MtkCameraParameters::KEY_ENG_PARAMETER3[] = "key-eng-parameter3";

const char MtkCameraParameters::KEY_ENG_SAVE_SHADING_TABLE[] = "eng-save-shading-table";
const char MtkCameraParameters::KEY_ENG_SHADING_TABLE[] = "eng-shading-table";
const int MtkCameraParameters::KEY_ENG_SHADING_TABLE_AUTO = 0;
const int MtkCameraParameters::KEY_ENG_SHADING_TABLE_LOW = 1;
const int MtkCameraParameters::KEY_ENG_SHADING_TABLE_MIDDLE = 2;
const int MtkCameraParameters::KEY_ENG_SHADING_TABLE_HIGH = 3;
const int MtkCameraParameters::KEY_ENG_SHADING_TABLE_TSF = 4;

// KEY for [Engineer Mode] Add new camera paramters for ev calibration
const char MtkCameraParameters::KEY_ENG_EV_CALBRATION_OFFSET_VALUE[] = "eng-ev-cal-offset";

#ifdef MTK_SLOW_MOTION_VIDEO_SUPPORT
// High Speed Video Record
const char MtkCameraParameters::KEY_HSVR_PRV_SIZE[] = "hsvr-prv-size";
const char MtkCameraParameters::KEY_SUPPORTED_HSVR_PRV_SIZE[] = "hsvr-prv-size-values";
const char MtkCameraParameters::KEY_HSVR_PRV_FPS[] = "hsvr-prv-fps";
const char MtkCameraParameters::KEY_SUPPORTED_HSVR_PRV_FPS[] = "hsvr-prv-fps-values";
#endif
const char MtkCameraParameters::KEY_DXOEIS_ONOFF[] = "dxo-eis";
const char MtkCameraParameters::KEY_FIX_EXPOSURE_TIME[] = "fix-exposure-time";

}; // namespace android

